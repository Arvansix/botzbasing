const TelegramBot = require('node-telegram-bot-api');
const { handleHelp } = require('./commands/help');
const { handleTransfer } = require('./commands/transfer');
const { handleBuyCoin } = require('./commands/buycoin');
const { handleDiceGame } = require('./commands/dicegame');
const { handleMyAccount } = require('./commands/myaccount');
const { handleAddCoin } = require('./commands/addcoin');
const { notifySpecialTransfer } = require('./utils/notifications');
const { handleReferral } = require('./commands/referral');

// Token Bot Telegram
const TOKEN = process.env.7371884408:AAHPxKm6MGo6n8QK6x7LxP_C3E0pZfDhnlM;

// Inisialisasi Bot
const bot = new TelegramBot(TOKEN, { polling: true });

// Database sederhana (bisa diganti dengan database nyata seperti MongoDB)
const users = {};

// Command Handlers
bot.onText(/\/start(?: (.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const referrerId = match ? match[1] : null;

    // Registrasi pengguna baru jika belum ada
    if (!users[userId]) {
        users[userId] = {
            id: userId,
            membershipDate: new Date(),
            referrals: [],
            level: 'reguler',
            balance: 0,
        };

        // Jika ada referrer, tambahkan ke daftar referral
        if (referrerId && users[referrerId]) {
            users[referrerId].referrals.push(userId);
            users[referrerId].balance += 10000; // Beri bonus 10.000 coin
            bot.sendMessage(referrerId, `🌟 You received 10,000 coins for referring a new user!`);
        }
    }

    bot.sendMessage(chatId, "Welcome! Use /help to see available commands.", {
        reply_markup: {
            keyboard: [
                ['👤 My Account', '🎮 Dice Game'],
                ['💸 Transfer', '🛒 Buy Coin'],
                ['🔗 Referral', 'ℹ️ Help']
            ],
            resize_keyboard: true
        }
    });
});

bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    switch (text) {
        case 'ℹ️ Help':
            handleHelp(bot, chatId);
            break;
        case '💸 Transfer':
            handleTransfer(bot, msg, users, notifySpecialTransfer);
            break;
        case '🛒 Buy Coin':
            handleBuyCoin(bot, chatId);
            break;
        case '🎮 Dice Game':
            handleDiceGame(bot, msg, users);
            break;
        case '👤 My Account':
            handleMyAccount(bot, msg, users);
            break;
        case '🔗 Referral':
            handleReferral(bot, msg, users);
            break;
    }
});

// Owner Command: Add Coin
bot.onText(/\/addcoin (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    // Cek apakah pengguna adalah owner
    if (userId === 7338353258) {
        handleAddCoin(bot, msg, users, match[1]);
    } else {
        bot.sendMessage(chatId, "You are not authorized to use this command.");
    }
});
function notifySpecialTransfer(bot, userId, level) {
    const alertMessage = `🌟 Alert! User ID ${userId} (${level.toUpperCase()}) has made a transfer! 🌟`;
    // Kirim notifikasi ke admin atau grup tertentu
    bot.sendMessage(ADMIN_CHAT_ID, alertMessage);
}

module.exports = { notifySpecialTransfer };
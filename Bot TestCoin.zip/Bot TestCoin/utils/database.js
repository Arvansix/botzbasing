const fs = require('fs');
const path = './database.json';

// Fungsi untuk membaca database
function readDatabase() {
    if (!fs.existsSync(path)) {
        fs.writeFileSync(path, '{}');
    }
    const data = fs.readFileSync(path, 'utf8');
    return JSON.parse(data);
}

// Fungsi untuk menulis ke database
function writeDatabase(data) {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
}

// Fungsi untuk mendapatkan data pengguna
function getUser(userId) {
    const db = readDatabase();
    return db[userId] || null;
}

// Fungsi untuk menambahkan pengguna baru
function addUser(userId) {
    const db = readDatabase();
    if (!db[userId]) {
        db[userId] = {
            id: userId,
            membershipDate: new Date().toISOString(),
            referrals: [],
            level: 'reguler',
            balance: 0,
        };
        writeDatabase(db);
    }
}

// Fungsi untuk memperbarui saldo pengguna
function updateUserBalance(userId, amount) {
    const db = readDatabase();
    if (db[userId]) {
        db[userId].balance += amount;
        writeDatabase(db);
    }
}

// Fungsi untuk memperbarui daftar referral
function addReferral(referrerId, referredId) {
    const db = readDatabase();
    if (db[referrerId]) {
        db[referrerId].referrals.push(referredId);
        writeDatabase(db);
    }
}

module.exports = {
    getUser,
    addUser,
    updateUserBalance,
    addReferral,
};
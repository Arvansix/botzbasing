function handleReferral(bot, msg, users) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    const referralLink = `https://t.me/@KebsosShopBot?start=${userId}`;
    const referralCount = users[userId]?.referrals.length || 0;

    const referralMessage = `
🔗 Your Referral Link:
${referralLink}

👥 Number of Referrals: ${referralCount} people

🎁 Reward: For each successful referral, you will receive 10,000 coins!
    `;

    bot.sendMessage(chatId, referralMessage);
}

module.exports = { handleReferral };
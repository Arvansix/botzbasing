function handleMyAccount(bot, msg, users) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    const user = users[userId];
    if (!user) {
        bot.sendMessage(chatId, "User not found. Please start the bot with /start.");
        return;
    }

    const accountDetails = `
👤 User ID: ${user.id}
👈 Membership date: ${user.membershipDate.toDateString()}
🔗 Number of referrals: ${user.referrals.length} people
🌟 User level: ${user.level}
💰 Balance: ${user.balance} coins
⏱ This status report is silent
    `;

    bot.sendMessage(chatId, accountDetails);
}

module.exports = { handleMyAccount };
function handleAddCoin(bot, msg, users, args) {
    const chatId = msg.chat.id;
    const [userId, amount] = args.split(' ');
    const parsedAmount = parseInt(amount);

    if (!users[userId] || isNaN(parsedAmount) || parsedAmount <= 0) {
        bot.sendMessage(chatId, "Invalid input. Usage: /addcoin <userId> <amount>");
        return;
    }

    users[userId].balance += parsedAmount;
    bot.sendMessage(chatId, `Added ${parsedAmount} coins to User ID ${userId}.`);
}

module.exports = { handleAddCoin };
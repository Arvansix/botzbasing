function handleBuyCoin(bot, chatId) {
    bot.sendMessage(chatId, "Please contact @ardemor to buy coins. Use the following format:\n\n/buycoin <amount>");
}

module.exports = { handleBuyCoin };
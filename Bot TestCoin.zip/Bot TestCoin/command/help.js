function handleHelp(bot, chatId) {
    const helpText = `
Available Commands:
/start - Start the bot
/help - Show this help message
/transfer - Transfer coins to another user
/buycoin - Buy coins from the owner
/dicegame - Play dice game with no bet limit
/myaccount - View your account details
/referral - View your referral link and stats

Owner Commands:
/addcoin <userId> <amount> - Add coins to a user's balance
    `;
    bot.sendMessage(chatId, helpText);
}

module.exports = { handleHelp };
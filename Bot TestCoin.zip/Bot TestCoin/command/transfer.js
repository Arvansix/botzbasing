function handleTransfer(bot, msg, users, notifySpecialTransfer) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    bot.sendMessage(chatId, "Enter the recipient's User ID and the amount to transfer (e.g., 123456789 100):", {
        reply_markup: { force_reply: true }
    });

    bot.onReplyToMessage(chatId, msg.message_id, (replyMsg) => {
        const [recipientId, amount] = replyMsg.text.split(' ');
        const parsedAmount = parseInt(amount);

        if (!users[recipientId] || isNaN(parsedAmount) || parsedAmount <= 0) {
            bot.sendMessage(chatId, "Invalid input. Please try again.");
            return;
        }

        if (users[userId].balance < parsedAmount) {
            bot.sendMessage(chatId, "Insufficient balance.");
            return;
        }

        // Proses transfer
        users[userId].balance -= parsedAmount;
        users[recipientId].balance += parsedAmount;

        bot.sendMessage(chatId, `Successfully transferred ${parsedAmount} coins to User ID ${recipientId}.`);

        // Notifikasi spesial untuk VIP/VVIP
        if (['vip', 'vvip'].includes(users[userId].level)) {
            notifySpecialTransfer(bot, userId, users[userId].level);
        }

        // Notifikasi ke penerima transfer
        bot.sendMessage(recipientId, `🌟 You have received ${parsedAmount} coins from User ID ${userId}.`);
    });
}

module.exports = { handleTransfer };
function handleDiceGame(bot, msg, users) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    bot.sendMessage(chatId, "Place your bet for the dice game (e.g., 50):", {
        reply_markup: { force_reply: true }
    });

    bot.onReplyToMessage(chatId, msg.message_id, (replyMsg) => {
        const betAmount = parseInt(replyMsg.text);

        if (isNaN(betAmount) || betAmount <= 0 || users[userId].balance < betAmount) {
            bot.sendMessage(chatId, "Invalid bet or insufficient balance.");
            return;
        }

        // Simulasi permainan dadu
        const diceRoll = Math.floor(Math.random() * 6) + 1;

        if (diceRoll >= 4) {
            users[userId].balance += betAmount;
            bot.sendMessage(chatId, `🎲 You rolled a ${diceRoll}! You win ${betAmount} coins.`);
        } else {
            users[userId].balance -= betAmount;
            bot.sendMessage(chatId, `🎲 You rolled a ${diceRoll}! You lose ${betAmount} coins.`);
        }
    });
}

module.exports = { handleDiceGame };